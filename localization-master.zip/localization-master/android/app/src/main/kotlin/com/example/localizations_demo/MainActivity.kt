package com.example.localizations_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
